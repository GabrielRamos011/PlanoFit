import React, { useState } from 'react';
import { Activity, Dumbbell, Heart, User } from 'lucide-react';

type UserData = {
  name: string;
  age: string;
  weight: string;
  height: string;
  goal: 'lose' | 'gain' | 'maintain';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'intense';
  dietaryRestrictions: string[];
  mealsPerDay: string;
};

function calculateCalories(userData: UserData) {
  // Fórmula de Harris-Benedict para TMB
  const weight = parseFloat(userData.weight);
  const height = parseFloat(userData.height);
  const age = parseFloat(userData.age);
  
  // TMB para uma pessoa média
  let tmb = 10 * weight + 6.25 * height - 5 * age;
  
  // Fator de atividade
  const activityFactors = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    intense: 1.725
  };
  
  const calories = tmb * activityFactors[userData.activityLevel];
  
  // Ajuste baseado no objetivo
  switch(userData.goal) {
    case 'lose':
      return Math.round(calories - 500); // Déficit para perda
    case 'gain':
      return Math.round(calories + 500); // Superávit para ganho
    default:
      return Math.round(calories); // Manutenção
  }
}

function App() {
  const [step, setStep] = useState(1);
  const [showPlan, setShowPlan] = useState(false);
  const [userData, setUserData] = useState<UserData>({
    name: '',
    age: '',
    weight: '',
    height: '',
    goal: 'lose',
    activityLevel: 'sedentary',
    dietaryRestrictions: [],
    mealsPerDay: '3',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUserData(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    if (step === 3) {
      setShowPlan(true);
    } else {
      setStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (showPlan) {
      setShowPlan(false);
    } else {
      setStep(prev => prev - 1);
    }
  };

  const calories = calculateCalories(userData);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-green-500" />
              <span className="ml-2 text-xl font-bold text-gray-900">MEU PLANO FIT</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-xl p-6 md:p-8">
          {!showPlan ? (
            <>
              <div className="flex items-center mb-8">
                {[
                  { icon: User, label: 'Dados Pessoais' },
                  { icon: Activity, label: 'Objetivos' },
                  { icon: Dumbbell, label: 'Atividade' },
                ].map((item, index) => (
                  <div key={item.label} className="flex-1">
                    <div className={`flex flex-col items-center ${index + 1 === step ? 'text-green-500' : 'text-gray-400'}`}>
                      <div className={`rounded-full p-3 ${index + 1 === step ? 'bg-green-100' : 'bg-gray-100'}`}>
                        <item.icon className="h-6 w-6" />
                      </div>
                      <span className="mt-2 text-sm font-medium">{item.label}</span>
                    </div>
                  </div>
                ))}
              </div>

              {step === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-900">Informações Pessoais</h2>
                  <div className="grid grid-cols-1 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                        Nome
                      </label>
                      <input
                        type="text"
                        name="name"
                        id="name"
                        value={userData.name}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="age" className="block text-sm font-medium text-gray-700">
                        Idade
                      </label>
                      <input
                        type="number"
                        name="age"
                        id="age"
                        value={userData.age}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-900">Seus Objetivos</h2>
                  <div className="grid grid-cols-1 gap-6">
                    <div>
                      <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
                        Peso Atual (kg)
                      </label>
                      <input
                        type="number"
                        name="weight"
                        id="weight"
                        value={userData.weight}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="height" className="block text-sm font-medium text-gray-700">
                        Altura (cm)
                      </label>
                      <input
                        type="number"
                        name="height"
                        id="height"
                        value={userData.height}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
                        Objetivo
                      </label>
                      <select
                        name="goal"
                        id="goal"
                        value={userData.goal}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      >
                        <option value="lose">Perder Peso</option>
                        <option value="gain">Ganhar Massa Muscular</option>
                        <option value="maintain">Manter Peso</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-900">Nível de Atividade</h2>
                  <div className="grid grid-cols-1 gap-6">
                    <div>
                      <label htmlFor="activityLevel" className="block text-sm font-medium text-gray-700">
                        Qual seu nível de atividade física?
                      </label>
                      <select
                        name="activityLevel"
                        id="activityLevel"
                        value={userData.activityLevel}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      >
                        <option value="sedentary">Sedentário (pouco ou nenhum exercício)</option>
                        <option value="light">Leve (exercício 1-3 vezes/semana)</option>
                        <option value="moderate">Moderado (exercício 3-5 vezes/semana)</option>
                        <option value="intense">Intenso (exercício 6-7 vezes/semana)</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="mealsPerDay" className="block text-sm font-medium text-gray-700">
                        Quantas refeições por dia você prefere?
                      </label>
                      <select
                        name="mealsPerDay"
                        id="mealsPerDay"
                        value={userData.mealsPerDay}
                        onChange={handleInputChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      >
                        <option value="3">3 refeições</option>
                        <option value="4">4 refeições</option>
                        <option value="5">5 refeições</option>
                        <option value="6">6 refeições</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-gray-900 text-center">Seu Plano Personalizado</h2>
              
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Informações Gerais</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-600">Nome: <span className="font-semibold">{userData.name}</span></p>
                    <p className="text-gray-600">Idade: <span className="font-semibold">{userData.age} anos</span></p>
                    <p className="text-gray-600">Peso: <span className="font-semibold">{userData.weight} kg</span></p>
                    <p className="text-gray-600">Altura: <span className="font-semibold">{userData.height} cm</span></p>
                  </div>
                  <div>
                    <p className="text-gray-600">Objetivo: <span className="font-semibold">
                      {userData.goal === 'lose' ? 'Perder Peso' : 
                       userData.goal === 'gain' ? 'Ganhar Massa' : 'Manter Peso'}
                    </span></p>
                    <p className="text-gray-600">Calorias Diárias: <span className="font-semibold">{calories} kcal</span></p>
                    <p className="text-gray-600">Refeições: <span className="font-semibold">{userData.mealsPerDay} por dia</span></p>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white border border-green-200 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Plano Alimentar</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-700">Café da Manhã</h4>
                      <p className="text-gray-600">• Aveia com leite desnatado e banana</p>
                      <p className="text-gray-600">• 2 ovos cozidos</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Almoço</h4>
                      <p className="text-gray-600">• 150g de frango grelhado</p>
                      <p className="text-gray-600">• 1 xícara de arroz integral</p>
                      <p className="text-gray-600">• Salada de folhas verdes</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Jantar</h4>
                      <p className="text-gray-600">• 150g de peixe assado</p>
                      <p className="text-gray-600">• Legumes no vapor</p>
                      <p className="text-gray-600">• Batata doce assada</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-green-200 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Plano de Treino</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-gray-700">Segunda-feira</h4>
                      <p className="text-gray-600">Peito e Tríceps</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Terça-feira</h4>
                      <p className="text-gray-600">Costas e Bíceps</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Quarta-feira</h4>
                      <p className="text-gray-600">Descanso</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Quinta-feira</h4>
                      <p className="text-gray-600">Pernas</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Sexta-feira</h4>
                      <p className="text-gray-600">Ombros e Abdômen</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-700">Sábado</h4>
                      <p className="text-gray-600">Cardio</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="mt-8 flex justify-between">
            {(step > 1 || showPlan) && (
              <button
                onClick={handleBack}
                className="bg-gray-100 text-gray-800 px-6 py-2 rounded-md hover:bg-gray-200 transition-colors"
              >
                Voltar
              </button>
            )}
            {!showPlan && (
              <button
                onClick={handleNext}
                className="ml-auto bg-green-500 text-white px-6 py-2 rounded-md hover:bg-green-600 transition-colors"
              >
                {step === 3 ? 'Criar Plano' : 'Próximo'}
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;